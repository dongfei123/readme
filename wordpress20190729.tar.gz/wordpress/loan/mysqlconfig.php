<?php

     $con =new mysqli("localhost","loan","loanroot","loan");

       //$id = $_GET['id'];
       $img=$_POST['ash_upload'];

       $name=$_POST['name'];
       $successrate=$_POST['successrate'];
       $money=$_POST['money'];
       $moneyrate=$_POST['moneyrate'];
       $describle=$_POST['describle'];
       $time=$_POST['time'];
       $speed=$_POST['speed'];

       $arrive=$_POST['arrive'];
       $href=$_POST['href'];
       $counts=$_POST['counts'];

       $cate_arr=$_POST['cate'];
       @$cate=implode(',',$cate_arr);
       $applys=$_POST['apply'];
       @$apply=implode('+',$applys);

       $catename=$_POST['catename'];
       $cateimg=$_POST['ash_upload1'];

      $money2=$_POST['money2'];
      $time2=$_POST['time2'];
      $caution=$_POST['caution'];

?>

