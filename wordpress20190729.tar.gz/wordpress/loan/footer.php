<link rel="stylesheet/less" type="text/css" href="http://www.eluedai.com/wp-content/themes/dux/css/index.less" />
<script src="//cdnjs.cloudflare.com/ajax/libs/less.js/3.8.1/less.min.js" ></script> 
<div style="height:80px;background:none;"></div>
<footer class="container bottom" style="left:0;">
              <ul style="margin:0;padding:0;">
                <li><a  class="home" href="http://www.eluedai.com/">首 页</a></li>
                <li><a class="customs-clearance" href="http://www.eluedai.com/forum">社 区</a></li>
                <li><a class="grade" href="http://www.eluedai.com/loan.html">借 款</a></li>
                <li><a class="display" href="http://www.eluedai.com/find.html">发 现</a></li>
                <li><a class="my">我 的</a></li>
             </ul>
</footer>