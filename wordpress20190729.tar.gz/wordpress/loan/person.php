   <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"><script src="http://www.eluedai.com/wp-content/themes/dux/js/libs/jquery.min.js"></script>
<div id="personcenter"><script>
$("#personcenter").load("http://www.eluedai.com .header");
</script></div>
