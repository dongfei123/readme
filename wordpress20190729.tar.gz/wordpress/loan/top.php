<meta charset="utf8">
<style>
  @media(min-width:450px){
      .download{display:none;}}
  .download img{padding: 28px 17px 0 10px;   width: 16px;}
  .download{margin:0;padding:0;width:100%;overflow:hidden;background:#f5f5f5;}
  .download .advise{position:fixed;top:0;width:100%;background:#f5f5f5;border-bottom:1px solid #ddd;z-index:20;height:74px;}
   .download .advise img,.download .advise p{float:left;}
  .download .advise a {margin:6% 5% 0% 0%;float:right;border:1px solid #277bef;color:#277bef;border-radius:2px;padding:4px;font-size:12px;}
  .download .advise p{padding: 4%;margin:0;}
    .goback {display:none;padding: 10px 0 10px 6%;border-bottom:1px solid #f6f6f6;background: white;}
    .goback img{width:20px;}

</style>
<div class="goback">
 <a href="javascript:history.go(-1)"><img src="http://www.eluedai.com/wp-content/uploads/2019/06/箭头-左-细.png"></a>
   <!--<a href="javascript:window.history.forward()">>></a>-->
</div>
<div class="download">
<div style="height:74px;"></div>
<div class="advise"><img src="http://www.eluedai.com/wp-content/uploads/2019/06/close.png">
<p>最新口子实时更新<br>百万老哥在线交流</p>
<a href="http://www.kxapp.com/app/download/59048">点击下载app</a></div>

</div>
<script src="http://www.eluedai.com/wp-content/themes/dux/js/libs/jquery.min.js"></script>
<script>
  $(function(){
  $(".download .advise img").click(function(){
  $(".download").hide();
  })
function BrowserType()
{
var userAgent = navigator.userAgent; //取得浏览器的userAgent字符串

var isOpera = userAgent.indexOf("Opera") > -1; //判断是否Opera浏览器

var isIE = userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1 && !isOpera; //判断是否IE浏览器
var isEdge = userAgent.indexOf("Edge") > -1; //判断是否IE的Edge浏览器
var isFF = userAgent.indexOf("Firefox") > -1; //判断是否Firefox浏览器
var isSafari = userAgent.indexOf("Safari") > -1 && userAgent.indexOf("Chrome") == -1; //判断是否Safari浏览器
var isChrome = userAgent.indexOf("Chrome") > -1 && userAgent.indexOf("Safari") > -1; //判断Chrome浏览器
  var QQ= userAgent.indexOf("QQ") > -1;
  var Uc = userAgent.indexOf("UC") > -1;
if(QQ||isSafari||isIE||isEdge|| isFF||Uc){
$(".download").show();
    $(".footer").show();
}else{
$(".download").hide();
    $(".footer").hide();
    $(".goback").show();
}
}
    BrowserType();
  })

</script>