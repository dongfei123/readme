<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta charset="utf8">
<link rel="stylesheet/less" type="text/css" href="http://www.eluedai.com/wp-content/themes/dux/css/loan.less" />
<?php
require 'top.php';
//从数据库列出分类
require 'mysqlconfig.php';
$selectcalc ="select * from cateloan order by caterank desc limit 8";
$rescalc=$con->query($selectcalc);
echo "<div class='catelogy'><ul >";
while($discalc=$rescalc->fetch_row()){
   echo " <li><a href='$discalc[0].html'><img src='$discalc[1]'>$discalc[2]</a></li> ";
}
echo "</ul></div>";
?>

<div class="todaylist">
    <strong>今日下款</strong>
    <ul id='today'style="height: 20px;overflow: hidden;">
        <?php

        //选取指定的产品
        $product="select * from product ";

        $productres=$con->query($product);

        $productrow=$productres->fetch_row();
        //echo $productrow[0];

        $select="select * from info where id REGEXP '$productrow[1]'";
       //echo $select;
        $res=$con->query($select);
       // var_dump($res);
        while($row=$res->fetch_row()){
            echo "<li><a href='info/{$row[0]}.html'>
      $row[2]<span>成功率:<strong>$row[3]%</strong></span></a></li>";
       }
        ?>
</div>

<div class="newhot" >
    <table width="100%"><tr><td id='newopen'>最新口子</ ></td><td id='hotopen'>热门口子</td></tr></table>

    <?php
    $select="select * from info order by id desc";
    $res=$con->query($select);
    echo "<div id='open1' >";
    while($row=$res->fetch_row()){
        echo "<div><a  href='info/{$row[0]}.html'>
        <img  src=$row[1]>
      <section> <h2>{$row[2]}<span>成功率:<strong>{$row[3]}%</strong></span></h2>
       <p>额度:<strong>{$row[4]}-{$row[14]}元</strong><span>费率:<strong>{$row[5]}%/日</strong></span></p>
       <p>{$row[6]}</p></section>
</a></div>";
    }
    echo "</div>";
    $select="select * from info order by counts desc";
    $res=$con->query($select);
    echo "<div id='open2' style='display: none;'>";
    while($row=$res->fetch_row()){
        echo "<div><a  href='info/{$row[0]}.html'>
        <img  src=$row[1]>
      <section> <h2>{$row[2]}<span>成功率:<strong>{$row[3]}%</strong></span></h2>
       <p>额度:<strong>{$row[4]}-{$row[14]}元</strong><span>费率:<strong>{$row[5]}%/日</strong></span></p>
       <p>{$row[6]}</p></section>
</a></div>";
    }
    echo "</div>";
    mysqli_close($con);
    ?>
</div>
  <?php require 'footer.php';?>

<script src="http://www.eluedai.com/wp-content/themes/dux/js/libs/jquery.min.js"></script>
<script>
    $(function(){
        $("#hotopen").click(function(){
            $("#open2").show();
            $("#open1").hide();
            $(this).css({"border-bottom":"2px solid #01c3ac"});
            $("#newopen").css("border","none");
        })
        $("#newopen").click(function(){
            $("#open1").show();
            $("#open2").hide();
            $(this).css({"border-bottom":"2px solid #01c3ac"});
            $("#hotopen").css("border","none");
        })
    })

    $(function(){
//每隔两秒进行一次滚动
        var timing =setInterval("info()",2000);
        $("#today").hover(
            function(){clearInterval(timing);},
            function(){timing = setInterval("info()",2000);}
        )
    })
    function info(){
//复制第一个li
        var li =$("#today>li:eq(0)").clone();
//使用animate对li的外边距进行调整从而达到向上滚动的效果
        $("#today>li:eq(0)").animate({marginTop:"-20px"},2000,function(){
//对已经消失的li进行删除
            $("#today>li:eq(0)").remove();
//把复制后的li插入到最后
            $("#today").append(li);
        })
    }
</script>
