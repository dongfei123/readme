<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta charset="utf8">
<link rel="stylesheet/less" type="text/css" href="http://www.eluedai.com/wp-content/themes/dux/css/product.css" />
    <?php
require 'top.php';
    require 'mysqlconfig.php';
    $id=$_GET['id'];

    //获取分类名称
    $catelist="select * from cateloan where id='{$id}'";
   $cateres=$con->query($catelist);
    $caterow=$cateres->fetch_row();

   $select="select * from info where cate like '%$caterow[2]%'";
    $res=$con->query($select);
    while($row=$res->fetch_row()){
echo "<div class='catelist'>
<a  style='color:black;' href='info/{$row[0]}.html'>
<img src=$row[1]>
<span>
<h2>{$row[2]}</h2>
<p class='right'>成功率:<strong>{$row[3]}%</strong></p>
<p style='float:left;'>额度:<strong>{$row[4]}-{$row[14]}元</strong></p>
<p class='right'>费率:<strong>{$row[5]}%/日</strong></p>
<p>{$row[6]}</p></span></a></div>";

    }

    mysqli_close($con);

    ?>

<?php require 'footer.php';?>

