<!DOCTYPE HTML>
<html><head>
  <meta  charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
  </head>
<style>
    *{margin:0;padding:0;}
    a {text-decoration: none;color:#666;}
    .lists-name {color: #222222;
        font-weight:normal;
        font-size: 0.8em;
        padding:3% 0 0% 6%;}
    .mt20 {overflow:hidden;margin-top:6px;background:#fff;}
    body {background:#eee;}
    .white {margin-top:0;}
    .apploan img{width:40px;display: block;margin:0 auto;padding-top:11px;}
    .apploan li {float: left;width:25%;text-align: center;overflow: hidden;
        white-space: nowrap;border-bottom: 1px solid #eee;padding-bottom:10px;}
    .apploan li a{font-size:10px;color:black;}

</style>
<body>

  <?php
  require "top.php";?>
  <?php
  //$select="select * from cateloan";
 // $query=$con->query($select);
  ?>
<div class="mt20 white">
    <div class="recom-lists">
        <?php
          require "mysqlconfig.php";
           $catequery="select * from cateloan where id=9";
           $cateres=$con->query($catequery);
           $caterow=$cateres->fetch_row();
           //echo $caterow[2];
          echo "<h2 class='lists-name'> $caterow[2]</h2>
        <ul class='apploan'>";

           $select="select * from find where category like '%$caterow[2]%'";

           $query=$con->query($select);
           while ($row=$query->fetch_row()){
               echo "<li><a href='$row[3]'><img src='$row[1]'>$row[2]</a></li>";
           }
        ?>       

        </ul>
    </div>
</div>
  <div class="mt20">
      <div class="recom-lists">
          <?php
          require "mysqlconfig.php";
          $catequery="select * from cateloan where id=10";
          $cateres=$con->query($catequery);
          $caterow=$cateres->fetch_row();
          //echo $caterow[2];
          echo "<h2 class='lists-name'> $caterow[2]</h2>
        <ul class='apploan'>";

          $select="select * from find where category like '%$caterow[2]%'";

          $query=$con->query($select);
          while ($row=$query->fetch_row()){
              echo "<li><a href='$row[3]'><img src='$row[1]'>$row[2]</a></li>";
          }
          ?>

          </ul>
      </div>
  </div>
  <div class="mt20">
      <div class="recom-lists">
          <?php
          require "mysqlconfig.php";
          $catequery="select * from cateloan where id=11";
          $cateres=$con->query($catequery);
          $caterow=$cateres->fetch_row();
          //echo $caterow[2];
          echo "<h2 class='lists-name'> $caterow[2]</h2>
        <ul class='apploan'>";

          $select="select * from find where category like '%$caterow[2]%'";

          $query=$con->query($select);
          while ($row=$query->fetch_row()){
              echo "<li><a href='$row[3]'><img src='$row[1]'>$row[2]</a></li>";
          }
          ?>

          </ul>
      </div>
  </div>
  <div class="mt20">
      <div class="recom-lists">
          <?php
          require "mysqlconfig.php";
          $catequery="select * from cateloan where id=12";
          $cateres=$con->query($catequery);
          $caterow=$cateres->fetch_row();
          //echo $caterow[2];
          echo "<h2 class='lists-name'> $caterow[2]</h2>
        <ul class='apploan'>";

          $select="select * from find where category like '%$caterow[2]%'";

          $query=$con->query($select);
          while ($row=$query->fetch_row()){
              echo "<li><a href='$row[3]'><img src='$row[1]'>$row[2]</a></li>";
          }
          ?>

          </ul>
      </div>
  </div>





<?php require "footer.php";?>

</body></html>