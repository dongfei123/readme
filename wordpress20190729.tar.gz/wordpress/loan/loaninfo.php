<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta charset="utf8">
<link rel="stylesheet" type="text/css" href="http://www.eluedai.com/wp-content/themes/dux/css/loaninfo.css" />
<link rel="stylesheet/less" type="text/css" href="http://www.eluedai.com/wp-content/themes/dux/css/product.css" />
<?php
require 'top.php';
require "mysqlconfig.php";
$id=$_GET['id'];
$select="select * from info where id=$id";
$result=$con->query($select);
$row=$result->fetch_row();
?>
<div class="product">
   <img src="<?php echo $row[1]?>">
   <span> <h1><?php echo $row[2]?></h1>
    <p>申请成功率：<strong><?php echo $row[3].'%'?></strong></p>
    <p><?php echo $row[6]?></p>
 <span>
</div>
<div class="caution"><?php echo $row[16]?></div>
<div class="pinfo"><ul>
        <li>额度<strong><?php echo $row[4].'-'.$row[14]?>元</strong></li>
        <li>期限<strong><?php echo $row[7].'-'.$row[15]?>天</strong></li>
        <li>费用<strong><?php echo $row[5]?></strong>%/日</li>
        <li style="width:100%;border-bottom:1px solid #f6f6f6;"></li>
        <li>放款速度<strong><?php echo $row[8]?>分钟</strong></li>
        <li>审核方式<strong><?php echo $row[9]?></strong></li>
        <li>到账方式<strong><?php echo $row[10]?></strong></li>
    </ul></div>
<div class="request"><p class="border">征信要求：<strong>无</strong></p>
    <p>平台名称：<strong><?php echo $row[2];?></strong></p></div>
<div class="apply"><h1 class="border">申请攻略</h1>
    <h2 >产品名称:<?php echo $row[2];?></h2>
    <p>贷款金额：<?php echo $row[4].'-'.$row[14];?>元</p>
    <p>贷款期限: <?php echo $row[7].'-'.$row[15];?>月</p>
    <p>贷款利率: <?php echo $row[5];?>%/日</p>

<a class="immediately" href="<?php echo $row[11];?>">立即申请</a></div>
<div class="rproduct">
  <h1>推荐产品<a href="loan.html">更多</a></h1>
    <?php
     //随机查询
     $select=" SELECT * FROM info WHERE id >= (SELECT floor(RAND() * (SELECT MAX(id) FROM info))) ORDER BY id LIMIT 6";
     $res=$con->query($select);
    while($row=$res->fetch_row()){
echo "<div class='catelist'>
<a  style='color:black;' href='{$row[0]}.html'>
<img src=$row[1]>
<span>
<h2>{$row[2]}</h2>
<p class='right'>成功率:<strong>{$row[3]}%</strong></p>
<p style='float:left;'>额度:<strong>{$row[4]}-{$row[14]}元</strong></p>
<p class='right'>费率:<strong>{$row[5]}%/日</strong></p>
<p>{$row[6]}</p></span></a></div>";
    }
    mysqli_close($con);
    ?>

</div>
<div id="totalcode"><script>
        $("#totalcode").load("http://www.eluedai.com/wp-admin/themes.php?page=options-framework #trackcode");
       console.log($("#trackcode").text());

    </script></div>

<div style="height:50px;"></div>
<?php require 'footer.php';?>

